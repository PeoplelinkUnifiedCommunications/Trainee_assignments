import { useState, useEffect } from 'react';
import axios from 'axios';

const HookApiCalls = (url) => {
    const [ApiData, setApiData] = useState([])
    
    useEffect(() => {
        const getName = async () => {
          await axios.get(url)
           .then(resp => setApiData(resp.data))
        };
        getName()
    },[url])

  return {ApiData}
  
}

export default HookApiCalls;