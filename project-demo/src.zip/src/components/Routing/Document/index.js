import React from 'react';

const Document = () => {
  return (
      <div className="dashboardCntnr"  >
                <h1>Documents</h1>
                <h4>Total Products</h4>
                <h6>12900</h6>
      </div>
 );
};

export default Document;
