import React from 'react';

const Cart = () => {
  return (
      <div className="dashboardCntnr"  >
                <h1>Cart</h1>
                <h4>Total Products</h4>
                <h6>12900</h6>
      </div>
 );
};

export default Cart;
