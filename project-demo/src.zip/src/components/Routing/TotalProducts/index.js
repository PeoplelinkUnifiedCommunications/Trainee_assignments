import React from 'react';
import SideNav from "../../SideNav"
const TotalProducts = () => {
  return (
    <div className='dashboardCntnr'>
      <h1>Total Views</h1>
  </div>
  )
};

export default TotalProducts;