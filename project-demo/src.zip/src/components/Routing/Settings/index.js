import React from 'react';

const Settings = () => {
  return (
      <div className="dashboardCntnr"  >
                <h1>Settings</h1>
                <h4>Total Products</h4>
                <h6>12900</h6>
      </div>
 );
};

export default Settings;
