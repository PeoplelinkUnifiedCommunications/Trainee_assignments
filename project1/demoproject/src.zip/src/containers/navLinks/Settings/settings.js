import React from 'react';


const Settings = () => {
  
  return (
    <div className='dashBoardCntnr'>
    <h1>Settings</h1>
    </div>
  )
};

export default Settings;