import React from 'react';
import SideNav from '../sideNav/index';


const Info = () => {
  
  return (
    <div className='contentCntnr' >
    <SideNav />
    <div className='dashBoardCntnr'>
    
    </div>
    </div>
  )
};

export default Info;