import React from 'react';

const Cart = () => {
  
  return (
    <div className='dashBoardCntnr'>
    <h1>Cart</h1>
    </div>
    
  )
};

export default Cart;
