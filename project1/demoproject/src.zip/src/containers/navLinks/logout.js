import React from 'react';
import SideNav from '../../sideNav/index';


const Logout = () => {
  
  return (
    <div className='contentCntnr' >
    <SideNav />
    <div className='dashBoardCntnr'>
    
    </div>
    </div>
  )
};

export default Logout;