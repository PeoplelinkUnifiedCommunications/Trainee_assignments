import React from 'react';



const Document = () => {
  
  return (
    
    <div className='dashBoardCntnr'>
    <h1>Document</h1>
    </div>
    
  )
};

export default Document;