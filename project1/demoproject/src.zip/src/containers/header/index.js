import React from 'react';
import './index.css'
import avthar from '../images/avthar.jpg'
import { RiFileCopyFill } from "react-icons/ri";
import { FiSearch } from "react-icons/fi";
import { AiOutlineMessage } from "react-icons/ai";
import { FiBell } from "react-icons/fi";
import Tooltip from '@material-ui/core/Tooltip';
import Avatar from '@material-ui/core/Avatar';
import {Select, MenuItem} from '@material-ui/core';






const Header = () => {
  return (
     <div className=' flexRow fxdTopHdr main'>
         <div className=' flexMinWidth'>
             <div className='icon'>
                 <RiFileCopyFill className='iconSizeAndClr'/>  
             </div>
             <div className='searchCntnr'>
             <div className='search-icon'>
                 <FiSearch />
                 <input className='search-input' type='search' placeholder='Search for transaction,item,etc' />
             </div>
             <div className='search-btn'>
                 <Tooltip title="Search Button" arrow>
                 <button className='btn'>Search</button>
                 </Tooltip>
             </div>
             </div>
         </div>

         <div className='headerRhtCntnr'>
                <Tooltip title="message" arrow>
                   <div className='flexAuto iconCntnr'>
                   <AiOutlineMessage className='iconSize'/><span className='count'></span>
                   </div>
                </Tooltip>

                <Tooltip title='Notifications' arrow>
                    <div className='Auto iconCntnr'>
                    <FiBell className='iconSize' /><span className='count'></span>
                    </div>
                </Tooltip>
        <Tooltip title='Profile' arrow>
         {/* <img src={avthar} alt="Avatar" className="avatar"></img> */}
         <Avatar alt="Remy Sharp" src={avthar}/>
        </Tooltip>
         {/* <select className="drop" id="cars">
           
        </select> */}
        <Select labelId="label" id="select" >
        <MenuItem >one</MenuItem>
        <MenuItem >two</MenuItem>
        </Select>
         </div>

     </div>
  );
};

export default Header;
