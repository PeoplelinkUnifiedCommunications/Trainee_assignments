import { useEffect, useState } from 'react';
import axios from 'axios'
import Card from '../Card';
import SideNav from '../sideNav';
import './index.css'
import Table from '../tableCard';
import Graph from '../grapgh';

// import eye from '../images/view.png'
// import bag from '../images/shopping-bag.png'
// import friends from '../images/group.png'
// import cart from '../images/shopping-cart.png'
// import wgraph from '../images/wchart.png'
// import rgraph from '../images/rchart.png'
// import ggraph from '../images/gchart.png'

const Body = () => {

  const [bodydata, setBodyData] = useState([])

    const getName=async()=>{
    const url="http://localhost:5000/cardData";
    await axios.get(url)
    .then(resp=>setBodyData(resp.data))
  }
  
  useEffect(()=>{
    getName()
  },[])
  
  // let data=[{id:1,imgVal:eye,graph:wgraph,views:360.402,date:"Start from jan1 2021"},
  //           {id:2,imgVal:bag,graph:rgraph,views:10.820,date:"+ Add New Product"},
  //           {id:3,imgVal:friends,graph:ggraph,views:8.425,date:"New user noted every week"},
  //           {id:4,imgVal:cart,graph:ggraph,views:1.028623,date:"Start from 1 Jan 2021"}]
      
  return(

       <div className='dashBoardCntnr'>
         <div className='filter'>
         <h1>Dashboard</h1>
         <select>
           <option>Last one month</option>
           <option>Last three months</option>
           <option>Last six months</option>
           <option>Custom</option>
         </select>
         </div>
         <div className='mapping'>
           {bodydata && bodydata.map(card=>(<Card key={card.id} list={card}/>))}
         </div>
         <div className='tbleGrpCntnr'>
          <Table />
          <Graph />
         </div>
       </div>
  );
};

export default Body;
