import React, {useState,useEffect} from 'react';
import axios from 'axios';
import {useParams} from 'react-router-dom'


const ViewsCount = () => {
  const [countlist, setCountList] = useState([])

  const {id} = useParams()

    const getViewsData=async()=>{
    await axios.get(`http://localhost:5000/viewsData/${id}`)
    .then(resp=>setCountList(resp.data))
  }
  
  useEffect(()=>{
    getViewsData()
  },[id])

  const {product, imgUrl, views, sells, users} = countlist

  
  return (
    
    <div className='dashBoardCntnr'>
    <center>
    <h1>Views and Sales Count</h1>
     <img src={imgUrl} alt='gfhg' style={{height:'400px', width:'400px'}}/>
      <h1>Product Name:-{product}</h1>
      <h1>Views: {views}</h1>
      <h1>Sells: {sells}</h1>
      <h1>Users: {users}</h1>
      </center>
    </div>
  )
};

export default ViewsCount;
