import React, {useState,useEffect} from 'react';
import axios from 'axios';
import List from '../oneItem/index';

const TotalViews = () => {
  const [viewData, setViewData] = useState([])


    const getViews=async()=>{
    const url="http://localhost:5000/viewsData";
    await axios.get(url)
    .then(resp=>setViewData(resp.data))
  }
  
  useEffect(()=>{
    getViews()
  },[])


  return (

    <div className='dashBoardCntnr'>
     <div className='flexcol'>
       <div className='flexRow jcBetween'>
       <h1>ID</h1>
       <h1>Product Name</h1>
       <h1>Views</h1>
       </div>
       {viewData && viewData.map(each=><List key={each.id} datasend={each}/>)}
    </div>
  </div>
  )
}
export default TotalViews;
