import React from 'react';


const TotalProducts = () => {
  return(
    <div className='dashBoardCntnr'>
      <h1>total products</h1>
    </div>
  );
};

export default TotalProducts;
