import React from 'react';
import { useNavigate } from "react-router-dom";

const List = (props) => {
  const {datasend}=props
  const {id,product,views}=datasend
  const navigation=useNavigate()
  const NavigateToSingle=()=>{
    navigation(`/views/${id}`)
    }
  return (<div onClick={NavigateToSingle}>
      <div className="flexRow jcBetween brdrBottomSM"  >
                <h1>{id}</h1>
                <h1>{product}</h1>
                <h1>{views}</h1>
            </div>
          </div>);
};

export default List;