import React from 'react';

const TotalUsers = () => {
  return (
   
    <div className='dashBoardCntnr'>
      <h1>Total Users</h1>
    </div>
  
  )
};

export default TotalUsers;
