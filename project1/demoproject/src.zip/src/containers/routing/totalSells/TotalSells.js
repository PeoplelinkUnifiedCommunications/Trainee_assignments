import React from 'react';


const TotalSells = () => {
  return (
    <div className='dashBoardCntnr'>
      <h1>Total sells</h1>
    </div>
  )
};

export default TotalSells;
