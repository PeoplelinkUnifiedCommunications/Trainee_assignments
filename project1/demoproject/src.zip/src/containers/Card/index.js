import React from 'react';
import {useNavigate} from 'react-router-dom'

import './index.css'
const Card = (props) => {
    const {list}=props
    const {id,isActiveCard,icon,cardType,chart,views,text,path}=list
    const navigation=useNavigate()

  const cardCntnr =isActiveCard === true ? 'actcardCntnr':'inActcardCntnr'
  const NavigeteToPath=()=>{
      navigation(path)
  }
    
  return(
           <div className={cardCntnr} onClick={NavigeteToPath}>
               
               <div className='cardImages flexRow jcBetween'>
                   <div className='imageBg'>
                      <img  src={icon} alt="icon" className='imageSize'/>
                   </div>
                   <div>
                      <img src={chart} alt="icon" className='imageSize'/>
                   </div>
               </div>
                   <p className='fontSize'>{cardType}</p>
                   <p className='viewsFontSize'>{views}</p>
                   <hr />
                   <p className='fontSize'>{text}</p>
                
           </div>

  );
};

export default Card;
