import "./index.css";
import { useEffect, useState } from "react";
import axios from "axios";

const Table = () => {
  const [info, setinfo] = useState([])
    const getName=async()=>{
    const url="http://localhost:5000/table";
    await axios.get(url)
    .then(resp=>setinfo(resp.data))
  }
  
  useEffect(()=>{
    getName()
  },[])
  
  return (
    <div className="tableCntnr">
      <table className="tableRowGap">
        <tbody>
          <tr className="trow" >
            <th className="number">No</th>
            <th className="pName">Product Name</th>
            <th className="status">Status</th>
            <th className="sold">Sold</th>
            <th className="view">View</th>
          </tr>
          {info && info.map((each) => (
            <tr key={each.id}>
              <td className="mrgnBtm">{each.id}</td>
              <td>
              <div className='flexRow jcCntr alignCntr'>
                   <img src={each.photo} className='imgSize' alt="tablelogo" />
                   <p>{each.photoinfo}</p>
              </div>
              </td>
              <td>{each.status}</td>
              <td>{each.sold}</td>
              <td>{each.view}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Table;
