

import Forms from './Components/Forms'

function App (){
   return(
     <div>
       <Forms/>
     </div>
   )
}

export default App