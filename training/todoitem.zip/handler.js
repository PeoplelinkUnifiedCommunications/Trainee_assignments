require('dotenv').config({ path: './variables.env' });
const connectToDatabase = require('./db');
const TodoItem = require('./todo/model');

module.exports.create = async (event) => {
  return new Promise(async (resolve, reject) => {
    try {
      await connectToDatabase();
      let data = JSON.parse(event.body)      
      const result = await TodoItem.create(data)
      console.log(result)
      const body = {
        statusCode: 200,
        body: JSON.stringify(result)
      }
      return resolve(body);
    } catch (err) {
      const body = {
          statusCode: err.statusCode || 500,
          headers: {'Content-Type': 'text/plain'},
          body: 'Could not create the object'
      }
      return reject(body)
    }
  });
}